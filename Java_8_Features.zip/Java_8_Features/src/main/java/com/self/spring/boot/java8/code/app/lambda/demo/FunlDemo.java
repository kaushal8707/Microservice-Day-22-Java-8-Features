package com.self.spring.boot.java8.code.app.lambda.demo;

public class FunlDemo implements Runnable{

	@Override 
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
