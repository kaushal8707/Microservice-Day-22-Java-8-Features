package com.self.spring.boot.java8.code.app.stream.sort;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import com.self.spring.boot.java8.code.app.stream.api.example.Employee;

public class CustomObjectMapSortingStreamAPI {
	public static void main(String[] args) {
		Map<Employee,Integer> map=new HashMap<Employee,Integer>();
		map.put(new Employee(67, "Kaushal", "CSI", 896799), 654);
		map.put(new Employee(67, "Raju", "FDS", 75758), 987);
		map.put(new Employee(67, "Priyanka", "VGHU", 64573), 123);
		map.put(new Employee(67, "Kanishk", "KIPL", 97707), 234);
		map.put(new Employee(67, "Kittu", "BFSI", 32345), 758);
		
		map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getName)))
		    .forEach(System.out::println);
		System.out.println("============================================");
		map.entrySet().stream().sorted(Map.Entry.comparingByKey(Comparator.comparing(Employee::getSalary).reversed()))
	    .forEach(System.out::println);	
	}
}
