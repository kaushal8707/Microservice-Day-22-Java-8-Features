package com.self.spring.boot.java8.code.app.stream.api.example;

import java.util.ArrayList;
import java.util.List;

//DAO Layer
public class DataBase 
{
	public static List<Employee> getEmployee() {
		List<Employee> employees=new ArrayList<Employee>();
		employees.add(new Employee(312, "Raushan", "Civil",600000));
		employees.add(new Employee(771, "Sohan", "Core",900000));
		employees.add(new Employee(981, "Madhu", "Csc",400000));
		employees.add(new Employee(481, "Aman", "Libr",500000));
		employees.add(new Employee(123, "Dixit", "Mtdr",1200000));
		return employees;
	}
}
