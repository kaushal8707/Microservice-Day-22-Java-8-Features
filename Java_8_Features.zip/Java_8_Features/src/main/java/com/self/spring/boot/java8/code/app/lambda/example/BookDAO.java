package com.self.spring.boot.java8.code.app.lambda.example;
import java.util.ArrayList;
import java.util.List;

public class BookDAO
{
	public List<Book> getBooks()
	{
		List<Book> books=new ArrayList<Book>();
		books.add(new Book(576, "Core Java", 256));
		books.add(new Book(981, "Spring", 132));
		books.add(new Book(149, "Web Service", 98));
		books.add(new Book(651, "Hibernate", 321));
		return books;	
	}
}
