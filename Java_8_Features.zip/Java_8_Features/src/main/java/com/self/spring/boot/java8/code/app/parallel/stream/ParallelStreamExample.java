package com.self.spring.boot.java8.code.app.parallel.stream;
import java.util.stream.IntStream;

public class ParallelStreamExample {
      public static void main(String[] args) {
		
    //I will try to iterate the 100 records using both the Streams and see the Performance
    	  long start=0;
    	  long end=0;
    	  
    	  start=System.currentTimeMillis();
    	  IntStream.range(1, 10).forEach(System.out::println);
    	  end=System.currentTimeMillis();
    	  System.out.println("Plain Stream took time :" +(end-start));
    	  
    	  System.out.println("*********************************");
    	  
    	  start=System.currentTimeMillis();
    	  IntStream.range(1, 10).parallel().forEach(System.out::println);
    	  end=System.currentTimeMillis();
    	  System.out.println("Parallel Stream took time :" +(end-start));
    	  
    	  
    	  IntStream.range(1, 10).forEach(x->{
    		  
    		  System.out.println("Thread - "+Thread.currentThread().getName()+"   "+x);
    	  });
    	  IntStream.range(1, 10).parallel().forEach(x->{
    		  
    		  System.out.println("Thread - "+Thread.currentThread().getName()+"   "+x);
    	  });
	}

}
