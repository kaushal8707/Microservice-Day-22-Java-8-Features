package com.self.spring.boot.java8.code.app.lambda.demo;

//Lambda Expression Example
	interface Calculator
	{
		//void switchOn();
		//void sum(int input);
		int substract(int i1,int i2);
	}
	
	//Using Lambda Expression
	public class CalculatorImpl {
		
		//   ()    			->      		{ }
		//Parameter     Expression      Method Body
		
		public static void main(String[] args) {
//			Calculator calc = ()-> System.out.println("Invoke Switch On Method"); 
//			calc.switchOn();
			
//			Calculator calculator =(input)->System.out.println("Sum = "+input);	
//			calculator.sum(135);
		    
			Calculator calculator=(i1,i2)->{
				if(i2>i1)
					return (i2-i1); 
				else
					throw new RuntimeException(i2+"   is Less than "+i1);			
			};
			
			System.out.println(calculator.substract(12, 9));
		
		}		
	}

	//In Our Traditional Approach
//	public class CalculatorImpl implements Calculator
//	{
//		@Override
//		public void switchOn() {
//	     System.out.println("Invoke Switch On Method");
//		}
//		
//	   public static void main(String[] args) {
//		new CalculatorImpl().switchOn();
//	}	
//}




