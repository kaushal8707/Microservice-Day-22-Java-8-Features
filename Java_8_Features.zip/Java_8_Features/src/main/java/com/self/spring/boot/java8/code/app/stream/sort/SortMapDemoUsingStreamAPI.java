package com.self.spring.boot.java8.code.app.stream.sort;
import java.util.HashMap;
import java.util.Map;

public class SortMapDemoUsingStreamAPI {
	public static void main(String[] args) {
		Map<String,Integer> map=new HashMap<>();
		map.put("four", 4);
		map.put("eight", 8);
		map.put("ten", 10);
		map.put("two", 2);
		
	//Based	on Key Sorting
	map.entrySet().stream().sorted(Map.Entry.comparingByKey()).forEach(System.out::println);

	//Based	on Value Sorting
	map.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);

	}
	
}
