package com.self.spring.boot.java8.code.app.stream.demo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class ForEachDemo {
	public static void main(String[] args) {
		List<String> list=new ArrayList<String>();
		list.add("Murrit");
		list.add("john");
		list.add("piter");
		list.add("marek");
		list.add("mac");
		
		list.forEach(null);
		list.stream().forEach(t->System.out.println(t));
		
		Map<Integer,String> hashMap=new HashMap<Integer,String>();
		hashMap.put(1,"a");
		hashMap.put(2,"b");
		hashMap.put(3,"c");
		hashMap.put(4,"d");
		
		hashMap.forEach((key,value)->System.out.println(key+" : "+value));
		hashMap.entrySet().stream().forEach(obj->System.out.println(obj));
		
		Consumer<String> consumer = (t)->System.out.println(t); 
		for(String s:list)
		{
			consumer.accept(s);
		}		
	}
}
