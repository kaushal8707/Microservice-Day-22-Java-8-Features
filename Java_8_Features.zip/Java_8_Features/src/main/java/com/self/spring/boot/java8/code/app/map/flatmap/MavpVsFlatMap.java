package com.self.spring.boot.java8.code.app.map.flatmap;

import java.util.List;
import java.util.stream.Collectors;

public class MavpVsFlatMap {

	public static void main(String[] args) {

		List<Customer> list=EKartDataBase.getAll();
		//List<Customer> Convert List<String>    -->Data Transformation
		//mapping : customer->customer.getEmail()
		//customer->customer.getEmail()     one-to-one mapping
		List<String> emails=list.stream()
				.map(customer->customer.getEmail())
				.collect(Collectors.toList());
		System.out.println(emails); 
		//customer->customer.getPhoneNumbers()   --> one-to-Many mapping
		List<List<String>> phoneNumbers=list.stream()
				.map(customer->customer.getPhoneNumbers())
		        .collect(Collectors.toList());
		System.out.println(phoneNumbers); 
		//List<Customer> Convert List<String>    -->Data Transformation
		//mapping : customer-> phoneNumbers
		//
		List<String> phoneNumber=list.stream().
				flatMap(customer->customer.getPhoneNumbers().stream())
				.collect(Collectors.toList());
		System.out.println(phoneNumber);
	}
}
