package com.self.spring.boot.java8.code.app.optional.demo;

import java.util.Arrays;
import java.util.Optional;

import com.self.spring.boot.java8.code.app.map.flatmap.Customer;

public class OptionalDemo {

	public static void main(String[] args) {
		Customer customer=new Customer(101, "john", null, Arrays.asList("8797651423","9191928273"));
		
		//empty()
		Optional emptyOptional=Optional.empty();
		System.out.println(emptyOptional);	
		
		//of()
		Optional<String> emailOptional=Optional.of(customer.getEmail());
		System.out.println(emailOptional);
		
		//ofNullable() 
		Optional<String> emailOptional2=Optional.ofNullable(customer.getEmail());
		if(emailOptional2.isPresent())
		{
			System.out.println(emailOptional2.get());
		}
		
		//orElse
		System.out.println(emailOptional2.orElse("default@gmail.com"));  //when Email is Null
		
		//orElseThrow    -> it take Supplier as an Input
		//System.out.println(emailOptional2.orElseThrow(()->new IllegalArgumentException("Email Not Found")));
		
		//orElseGet      -> it take Supplier as an Input
		System.out.println(emailOptional2.map(String::toUpperCase).orElseGet(()->"default email"));
	}
}
