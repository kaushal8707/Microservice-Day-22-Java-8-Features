package com.self.spring.boot.java8.code.app.stream.sort;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.self.spring.boot.java8.code.app.stream.api.example.DataBase;
import com.self.spring.boot.java8.code.app.stream.api.example.Employee;

public class CustomObjectSortingDemo 
{
	public static void main(String[] args) {
		List<Employee> employees=DataBase.getEmployee();
		Collections.sort(employees, new MyComparator());
		System.out.println(employees);
	}

}
class MyComparator implements Comparator<Employee>
{
	@Override
	public int compare(Employee o1,Employee o2)
	{
		return (int) (o1.getSalary()-o2.getSalary());
	}
}
