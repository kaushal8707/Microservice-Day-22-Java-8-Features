package com.self.spring.boot.java8.code.app.map.reduce;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.OptionalDouble;

public class MapReduceExample {

	public static void main(String[] args) {
		List<Integer> numbers=Arrays.asList(3,7,5,1,8,9);
		List<String> words=Arrays.asList("corejava","spring","hibernate");
		
		//mapToInt
		int sum=numbers.stream().mapToInt(i->i).sum();
		System.out.println(sum);
		
		//reduce    -> reduce takes input as an initial value and accumulator
		int reduceSum=numbers.stream().reduce(0, (a,b)->a+b);
		System.out.println(reduceSum);
		
		//reduce    -> reduce takes input as an Method Reference and return Optional
		Optional<Integer> reduceSumWithMethodReference=numbers.stream().reduce(Integer::sum);
		System.out.println(reduceSumWithMethodReference.get());
		
		int mulResult=numbers.stream().reduce(1, (a,b)->a*b);
		System.out.println(mulResult);
		
		int maxValue=numbers.stream().reduce(0,(a,b)->a>b?a:b);
		System.out.println(maxValue);
		
		//Method reference input return Optional
		int maxValueMethodReference=numbers.stream().reduce(Integer::max).get();
		System.out.println(maxValueMethodReference);
		
		//reduce can take input either Binary Function or (identity + Binary Function(accumulator)
		//in case we can't take identity
		//so BiFunction as an input return Optional type so used get()
		String longestString=words.stream().reduce((word1,word2)->word1.length()>word2.length()?word1:word2).get();
		System.out.println(longestString);

		//***********************
		//find the Average Salary of those Employee Whose Grade is A
		//get Employee whose grade A
		//get Salary
		List<Employee> employees=EmployeeDatabase.getEmployees();
		double avgSalary=employees.stream()
				               .filter(employee->employee.getGrade().equals("A"))
				               .map(Employee::getSalary)
				               .mapToDouble(i->i)
				               .average()      //bcz it returns Optional
				               .getAsDouble();
		System.out.println(avgSalary);
		
		//find the Sum Salary of those Employee Whose Grade is A
		//get Employee whose grade A
		//get Salary
		List<Employee> employees1=EmployeeDatabase.getEmployees();
		double sumSalary=employees1.stream()
		                       .filter(employee->employee.getGrade().equals("A"))
						       .map(Employee::getSalary)
						       .mapToDouble(i->i)
						       .sum();    //bcz it returns Optional
		System.out.println(sumSalary);

	}
}

