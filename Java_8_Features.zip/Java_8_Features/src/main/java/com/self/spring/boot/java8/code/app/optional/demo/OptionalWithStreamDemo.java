package com.self.spring.boot.java8.code.app.optional.demo;

public class OptionalWithStreamDemo {

	public static void main(String[] args) throws Exception {
		getCustomerByEmail("abc");
		getCustomerByEmail1("abc");

	}
	public static  Customer getCustomerByEmail(String email) throws Exception
	{
		return EKartDataBase.getAll()
				.stream().filter(customer->customer.getEmail().equals(email))
				.findAny().orElseThrow(()->new Exception("Email Not Found"));
	}
	public static  Customer getCustomerByEmail1(String email) throws Exception
	{
		return EKartDataBase.getAll()
				.stream().filter(customer->customer.getEmail().equals(email))
				.findAny().orElse(new Customer());
	}

}
