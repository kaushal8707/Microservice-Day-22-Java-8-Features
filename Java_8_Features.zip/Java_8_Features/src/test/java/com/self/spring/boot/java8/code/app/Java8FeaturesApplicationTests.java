package com.self.spring.boot.java8.code.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java8FeaturesApplicationTests {

	@Test
	void contextLoads() {
	}

}
