package com.java.selfdeveloped.spring.java8.api.model;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Employee1{
	private int id;
	private String name;
	private String grade;
	private double salary;
}
