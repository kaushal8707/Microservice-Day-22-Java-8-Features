package com.java.selfdeveloped.spring.java8.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java8LetsDoItApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java8LetsDoItApplication.class, args);
	}

}
