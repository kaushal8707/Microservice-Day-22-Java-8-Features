package com.java.selfdeveloped.spring.java8.api.important;
import java.util.Comparator;
import java.util.stream.Collectors;
import com.java.selfdeveloped.spring.java8.api.model.Employee1;
import com.java.selfdeveloped.spring.java8.api.model.EmployeeDatabase;

public class FindSecondHighestSalary {

	public static void main(String[] args) {
		String empName = EmployeeDatabase.getEmployees().stream()
				.sorted(Comparator.comparing(Employee1::getSalary).reversed())
			     .collect(Collectors.toList()).get(1).getName();
		System.out.println(empName);
	}

}
