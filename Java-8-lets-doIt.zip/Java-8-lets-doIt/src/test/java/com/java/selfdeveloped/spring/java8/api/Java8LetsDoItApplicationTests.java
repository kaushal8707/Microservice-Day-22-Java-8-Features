package com.java.selfdeveloped.spring.java8.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Java8LetsDoItApplicationTests {

	@Test
	void contextLoads() {
	}

}
